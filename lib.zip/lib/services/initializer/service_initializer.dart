class ServiceInitializer {
  Future<void> init() async {}
}
